package Base;

import Algorithms.UsefulMethods;

public class Target implements IEntity{
    private double xCoordinate, yCoordinate;//Hedefin koordinatları (alanın merkezi)
    private double area;//Hedefin büyüklüğü, alanı
    private int id = 0;//Hedef numarası
    private String name;//Hedefin ismi
    private String verificationCode;

    public Target(double xCoordinate, double yCoordinate, String name){
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;
        this.name = name;
    }
    public Target(double xCoordinate, double yCoordinate){
        this(xCoordinate, yCoordinate, "");
    }

//İŞLEM YÖNTEMLERİ:
    public float distanceTo(Target targetCity){//Verilen il ile arasında mesâfeyi döndürür (Öklit uzaklığı, kuş bakışı uzaklık)
        double distance = 0.0;
        distance = Math.abs(Math.pow((getxCoordinate() - targetCity.getxCoordinate()),2)) + Math.abs(Math.pow((getYCoordinate() - targetCity.getYCoordinate()),2));
        distance = Math.sqrt(distance);
        return (float) distance;
    }
    public float distanceTo(Target targetCity, int sensity){//Verilen il ile arasında mesâfeyi döndürür (Öklit uzaklığı, kuş bakışı uzaklık)
        double distance = 0.0;
        distance = Math.abs(Math.pow((getxCoordinate() - targetCity.getxCoordinate()),2)) + Math.abs(Math.pow((getYCoordinate() - targetCity.getYCoordinate()),2));
        distance = Math.sqrt(distance);
        return UsefulMethods.roundNumber((float)distance, sensity);
    }
    //YAN İŞLEM YÖNTEMİ:
    public void setVerificationCode(String code){
        this.verificationCode = code;
    }
    //YAN İŞLEM YÖNTEMİ:
    public void wantID(){
        this.id = UcusIDARE.getIDARE().takeIDForTarget(this);
    }

//ERİŞİM YÖNTEMLERİ:
    public int getID(){
        return id;
    }
    public double getxCoordinate() {
        return xCoordinate;
    }
    public double getYCoordinate(){
        return yCoordinate;
    }
    public String getName(){
        return name;
    }
    public double getArea(){
        return area;
    }
    public String getVerificationCode(){
        return verificationCode;
    }
}