package Base;

import java.util.HashMap;

public class Vehicle implements IEntity{
    private int id;//Araç numarası
    String name;//Araç ismi
    float minTurningDegree;//Aracın seyir hâlindeyken asğarî dönüş yarıçapı
    float minSpeed;//Aracın seyir hâlindeyken asğarî hızı
    float maxSpeed;//Aracın seyir hâlindeyken azamî hızı
    float range;//Metre cinsinden aracın menzili
    int[][] location;//'[y][x]' şeklinde aracın koordinatını belirten konum bilgisi
    private HashMap<Integer, Integer> speedsForDegrees;//Yapısı : <açı, o açıda aracın alabileceği azamî hız>
    private float fuelPercent;
    private String verificationCode;

    public Vehicle(int id, String name){
        this.id = id;
        this.name = name;
        fillForStandard();
    }
    public Vehicle(int id, String name, float minTurningDegree, float minSpeed, float maxSpeed, float range, int[][] location, HashMap<Integer, Integer> speedsForDegrees, float fuelPercent){
        this.id = id;
        this.name = name;
        this.minTurningDegree = minTurningDegree;
        this.minSpeed = minSpeed;
        this.maxSpeed = maxSpeed;
        this.range = range;
        this.location = location;
        this.speedsForDegrees = speedsForDegrees;
    }

//İŞLEM YÖNTEMLERİ:
    //YAN İŞLEM YÖNTEMİ:
    public void setVerificationCode(String code){
        this.verificationCode = code;
    }
    //YAN İŞLEM YÖNTEMİ:
    public void wantID(){
        this.id = UcusIDARE.getIDARE().takeIDForVehicle(this);
    }
    //GİZLİ İŞLEM YÖNTEMLERİ:
    private void fillForStandard(){
        //.;. : Kalan bilgileri ortalama bir insânsız hava aracı için doldur
    }

//ERİŞİM YÖNTEMLERİ:
    //
    public String getVerificationCode(){
        return verificationCode;
    }
    public int getID(){
        return id;
    }
    public String getName(){
        return name;
    }
}