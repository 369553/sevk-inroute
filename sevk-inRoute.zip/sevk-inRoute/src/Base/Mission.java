package Base;

import java.util.ArrayList;
import java.util.HashMap;

public class Mission implements IEntity{
    private int id;
    HashMap<Integer, MissionType> missionTypes;
    ArrayList<Target> targets;
    String name;
    HashMap<Integer, Double> minDistanceForNeededAttack;//Hedefin üzerinden geçmeyi
                                    //hedeflediğimiz saldırı çeşitleri dışındaki saldırı çeşitleri için
                                    //hedefe yaklaşmamız gereken asğarî mesâfeleri tutan harita
    private String verificationCode;

    public Mission(Target target){
        getTargets().add(target);
        getMissionTypes().put(target.getID(), MissionType.explore);
    }
    public Mission(Target[] targets, MissionType[] missionTypes){
        for(int sayac = 0; sayac < targets.length; sayac++){
            getTargets().add(targets[sayac]);
            this.getMissionTypes().put(targets[sayac].getID(), missionTypes[sayac]);
        }
    }
//İŞLEM YÖNTEMLERİ:
    public boolean removeTarget(Target target){
        for(Target t : getTargets()){
            if(t == target){
                getTargets().remove(target);
                getMissionTypes().remove(t.getID());
            }
        }
        //Exc? : Bu görev kapsamında ilgili hedef yok.
        return false;
    }
    //YAN İŞLEM YÖNTEMİ:
    @Override
    public void setVerificationCode(String code){
        this.verificationCode = code;
    }
    //YAN İŞLEM YÖNTEMİ:
    @Override
    public void wantID(){
        this.id = UcusIDARE.getIDARE().takeIDForMission(this);
    }

//ERİŞİM YÖNTEMLERİ:
    public HashMap<Integer, MissionType> getMissionTypes(){
        if(missionTypes == null)
            missionTypes = new HashMap<Integer, MissionType>();
        return missionTypes;
    }
    public String getVerificationCode(){
        return verificationCode;
    }
    public int getID(){
        return id;
    }
    public String getName(){
        return name;
    }
    public ArrayList<Target> getTargets(){
        if(targets == null)
            targets = new ArrayList<Target>();
        return targets;
    }
}