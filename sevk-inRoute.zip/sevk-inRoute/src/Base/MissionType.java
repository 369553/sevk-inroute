package Base;

public class MissionType{
    public static MissionType explore = new MissionType("explore");
    public static MissionType closeAttack = new MissionType("closeAttack");
    public static MissionType unCloseAttack = new MissionType("uncloseAttack");
    String missionTypeName;
    int minDistanceBetweenTargetForMission = 0;

    public MissionType(String missionTypeName){
        this.missionTypeName = missionTypeName;
        if(missionTypeName.equals("explore"))
            this.setMinDistanceBetweenTargetForMission(1);
        if(missionTypeName.equals("closeattack"))
            this.setMinDistanceBetweenTargetForMission(0);
        if(missionTypeName.equals("uncloseattack"))
            this.setMinDistanceBetweenTargetForMission(1);
    }
    public MissionType(String missionTypeName, int minDistanceBetweenTargetForMission){
        this.missionTypeName = missionTypeName;
        this.minDistanceBetweenTargetForMission = minDistanceBetweenTargetForMission;
    }

//İŞLEM YÖNTEMLERİ:
    public static MissionType produceUnCloseAttackWithDistance(int distance){
        MissionType attacking = new MissionType("uncloseAttack");
        if(distance > 1)
            attacking.setMinDistanceBetweenTargetForMission(distance);
        else
            attacking.setMinDistanceBetweenTargetForMission(1);
        return attacking;
    }
    public static MissionType produceExploreMissionWithDistance(int distance){
        MissionType exploring = new MissionType("explore");
        if(distance > 1)
            exploring.setMinDistanceBetweenTargetForMission(distance);
        else
            exploring.setMinDistanceBetweenTargetForMission(1);
        return exploring;
    }
    public void setMinDistanceBetweenTargetForMission(int minDistanceBetweenTargetForMission){
        this.minDistanceBetweenTargetForMission = minDistanceBetweenTargetForMission;
    }

//ERİŞİM YÖNTEMLERİ:
    
}