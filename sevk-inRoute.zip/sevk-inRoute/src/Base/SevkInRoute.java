package Base;

import Views.MainFrame;

public class SevkInRoute{
    public static void main(String[] args){
        //Giriş ekranını çalıştır
        //Giriş bilgileri ışığında ana ekranı çalıştır:
        MainFrame.getFrameMain().setVisible(true);
    }
}