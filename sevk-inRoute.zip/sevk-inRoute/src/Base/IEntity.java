
package Base;

public interface IEntity{
    public int getID();//Bulunduğu veri tipinde (tabloda) ayırt etmeyi sağlayan münhasır numara
    public void setVerificationCode(String code);//Değişkenin sisteme eklenebilmesi için sistemin o değişken için doğrulama kodunu vermesini sağlayan yöntem
    public String getVerificationCode();//Sisteme dâhil olabilmek için sistem tarafından verilen doğrulama kodu
    public void wantID();//Doğrulanmış değişkenin sistemden münhasır numara almasını sağlayan yöntem
    
}