package Base;

import Algorithms.IAlgorithm;
import Algorithms.UsefulMethods;

public class Problem{
    Target[] targets;//Ziyâret edilecek hedefleri barındıran değişken
    int[] targetIDs;//Hedeflerin hedef numaralarını barındıran değişken
    float[][] costTable;//Bir hedeften diğerine geçerken mâliyyetin ne olduğunu gösteren mâliyyet tablosu
    Target firstPoint;//Başlangıç noktası
    boolean isAppSensity = true, calculateWithCostMatrix = true, isCalculated = false;
    int sensity = 3;
    //isAppSensity : Hassaslık ayarını uygula
    //calculateWithCostMatrix : Hesaplama yaparken mâliyyet tablosunu kullan
    //isCalculated : Problemde herhangi bir değişiklik olmadan problem hesaplandı
    IAlgorithm algorithm;//Problemin çözümünde kullanılacak algoritma
    private Route lastCalculatedRoute;//Hesaplanan son güzergâh
    

    public Problem(){
        
    }
    public Problem(Target[] cities, Target startCity, boolean isAppSensity, int sensity){
        this.targets = cities;
        this.firstPoint = startCity;
        this.isAppSensity = isAppSensity;
        this.sensity = sensity;
        assignCityIDs();
        assignCostTable();
    }
    public Problem(Target[] targets, Target firstPoint){
        this(targets, firstPoint, false, 3);
    }
    public Problem(Target[] cities, Target startCity, float[][] costTable, boolean isAppSensity, int sensity){
        this.targets = cities;
        this.firstPoint = startCity;
        this.isAppSensity = isAppSensity;
        this.sensity = sensity;
        this.costTable = costTable;
        assignCityIDs();
    }
    public Problem(Target[] targets, Target firstPoint, float[][] costTable){
        this(targets, firstPoint, costTable, false, 3);
    }

//İŞLEM YÖNTEMLERİ:
    public Target findTargetByID(int targetID){
        for(Target t : getTargets()){
            if(t.getID() == targetID)
                return t;
        }
        return null;
    }
    public boolean setFirstPoint(Target target){
        if(target == null)
            return false;
        if(this.firstPoint != null){
            if(target.getID() == this.getFirstPoint().getID()){
                if(target.getxCoordinate() == this.getFirstPoint().getxCoordinate()){
                    if(target.getYCoordinate() == this.getFirstPoint().getYCoordinate())
                        return false;
                }
            }
        }
        if(findTargetByID(target.getID()) == null)
            return false;
        if(this.firstPoint != null)
            targetIDs = UsefulMethods.addVariableToArray(targetIDs, this.firstPoint.getID(), getTargetOrder(this.firstPoint.getID()));
        UsefulMethods.extractVariableFromArray(targetIDs, target.getID());
        this.firstPoint = target;
        isCalculated = false;
        lastCalculatedRoute = null;
        return true;
    }
    public boolean addTarget(Target target){
        if(target == null)
            return false;
        if(findTargetByID(target.getID()) != null)
            return false;
        targets = UsefulMethods.addVariableToArray(targets, target, targetIDs.length);
        float[] distancesToOther = new float[costTable.length], distancesToThis = new float[costTable.length];
        for(int index = 0; index < targets.length - 1; index++){
            if(isAppSensity)
                distancesToOther[index] = target.distanceTo(targets[index], sensity);
            else
                distancesToOther[index] = target.distanceTo(targets[index]);
        }
        distancesToThis = distancesToOther;
        costTable = UsefulMethods.addNewColToMatrixWithAddingToOtherRows(costTable, distancesToOther, distancesToThis);
        lastCalculatedRoute = null;
        return true;
    }
    public void setIsAppSensity(boolean isAppSensity){
        this.isAppSensity = isAppSensity;
    }
    public void setCalculateWithCostMatrix(boolean calculateWithCostMatrix){
        this.calculateWithCostMatrix = calculateWithCostMatrix;
    }
    public void setSensity(int sensity){
        if(sensity == this.sensity)
            return;
        this.sensity = sensity;
        lastCalculatedRoute = null;
    }
    public void setAlgorithm(IAlgorithm algorithm){
        this.algorithm = algorithm;
    }
    public int getTargetOrder(int targetID){
        for(int sayac = 0; sayac < targets.length; sayac++){
            if(targets[sayac].getID() == targetID)
                return sayac;
        }
        return -1;
    }
    //ARKAPLAN İŞLEM YÖNTEMLERİ:
    private void assignCityIDs(){
        int sayac = 0;
        targetIDs = new int[targets.length - 1];
    //    System.out.println("Sıralaması karıştırılacak belde sayısı : " + cityIDs.length);
        for(int index = 0; index < targets.length; index++){
            if(targets[index].getID() == firstPoint.getID()){
                continue;
            }
            targetIDs[sayac] = targets[index].getID();
            sayac++;
        }
    }
    private void assignCostTable(){
        costTable = new float[targets.length][targets.length];
        for(int index = 0; index < targets.length; index++){
            for(int index2 = 0; index2 < targets.length; index2++){
                if(index == index2){
                    costTable[index][index2] = 0;
                    continue;
                }
                if(index > index2){
                    costTable[index][index2] = costTable[index2][index];
                    continue;
                }
                if(isAppSensity)
                    costTable[index][index2] = targets[index].distanceTo(targets[index2], sensity);
                else
                    costTable[index][index2] = targets[index].distanceTo(targets[index2]);
            }
        }
    }

//ERİŞİM YÖNTEMLERİ:
    public Target[] getTargets(){
        return targets;
    }
    public int[] getTargetIDs(){
        return targetIDs;
    }
    public float[][] getCostTable(){
        return costTable;
    }
    public Target getFirstPoint(){
        return firstPoint;
    }
    public boolean isIsAppSensity(){
        return isAppSensity;
    }
    public boolean isCalculateWithCostMatrix(){
        return calculateWithCostMatrix;
    }
    public boolean isIsCalculated(){
        return isCalculated;
    }
    public IAlgorithm getAlgorithm(){
        return algorithm;
    }
    public Route getLastCalculatedRoute(){
        return lastCalculatedRoute;
    }
}