package Base;

import java.util.HashMap;

public class Map{
    private final int width, height;//Haritanın genişliği ve yüksekliği sâbit
    private String name;//Haritanın ismi
    private boolean[][] area;//Haritadaki alanların dolu olup, olmadığını gösteren bir matris
    private HashMap<String, Integer> targets;//Haritaya eklenen hedeflerin isim ve numaralarının tutulduğu harita

    public Map(int width, int height){
        this.width = width;
        this.height = height;
        area = new boolean[height][width];
        targets = new HashMap<String, Integer>();
        removeTargets();
    }

//İŞLEM YÖNTEMLERİ:
    public boolean addTargetToMap(Target target){
        if(target == null)
            return false;//Exc0 = Gelen veri null
        if(target.getxCoordinate() < 0 || target.getYCoordinate() < 0)
            return false;//Exc? = Koordinat harita sınırları dışında
        if(target.getxCoordinate() > width || target.getYCoordinate() > height)
            return false;//Exc? = Koordinat harita sınırları dışında
        for(int sayac = (int) (target.getxCoordinate() - (target.getArea() / 2)); sayac < (int) (target.getxCoordinate() + (target.getArea() / 2)); sayac++){
            for(int s2 = (int) (target.getxCoordinate() - (target.getArea() / 2)); s2 < (int) (target.getxCoordinate() + (target.getArea() / 2)); s2++){
                if(area[s2][sayac])
                    return false;//Exc? = Eklenmek istenen yerde başka hedef var
            }
        }
        for(int sayac = (int) (target.getYCoordinate() - (target.getArea() / 2)); sayac < ( int)(target.getArea()); sayac++){
            for(int s2 = (int) (target.getxCoordinate()- (target.getArea() / 2)); s2 < ( int)(target.getArea()); s2++){
                area[s2][sayac] = true;
            }
        }
        targets.put(target.getName(), target.getID());
        return true;
    }
    public boolean removeTargetFromMap(Target target){
        if(target == null)
            return false;//Exc0 = Gelen veri null
        if(target.getxCoordinate() < 0 || target.getYCoordinate() < 0)
            return false;//Exc? = Koordinat harita sınırları dışında
        if(target.getxCoordinate() > width || target.getYCoordinate() > height)
            return false;//Exc? = Koordinat harita sınırları dışında
        if(target.getName() == null)
            return false;//Exc? = Gelen veride istenen alt veri null
        if(targets.get(target.getName()) == null)
            return false;//Exc? = Hedef bu hatitada yok
        boolean check = true;
        for(int sayac = (int) (target.getYCoordinate() - (target.getArea() / 2)); sayac < (int) target.getArea(); sayac++){
            for(int s2 = (int) (target.getxCoordinate() - (target.getArea() / 2)); s2 < (int) target.getArea(); s2++){
                if(!area[s2][sayac]){//Hedefin bulunduğu alan haritada boş görünüyorsa
                    check = false;
                    break;
                }
            }
        }
        if(!check)
            return false;//Exc? = Hedef bu haritada yok; hedefin bulunduğu alan haritada boş olarak işâretli
        for(int sayac = (int) (target.getYCoordinate() - (target.getArea() / 2)); sayac < (int) target.getArea(); sayac++){
            for(int s2 = (int) (target.getxCoordinate() - (target.getArea() / 2)); s2 < (int) target.getArea(); s2++){
                area[s2][sayac] = false;
            }
        }
        targets.remove(target.getName());
        return true;
    }
    //ARKAPLAN İŞLEM YÖNTEMLERİ:
    private void removeTargets(){
        for(int sayac = 0; sayac < area.length; sayac++){
            for(int s2 = 0; s2 < area[0].length; s2++){
                area[sayac][s2] = false;
            }
        }
    }
    private double calculateFillingRateOfTheMap(){
        int filled = 0;
        for(int sayac = 0; sayac < height; sayac++){
            for(int s2 = 0; s2 < width; s2++){
                if(area[s2][sayac])
                    filled++;
            }
        }
        double rate = (filled / (width * height)) * 100;
        return rate;
    }

//ERİŞİM YÖNTEMLERİ:
    public int getWidth(){
        return width;
    }
    public int getHeight(){
        return height;
    }
    public boolean[][] getArea(){
        return area;
    }
    
}