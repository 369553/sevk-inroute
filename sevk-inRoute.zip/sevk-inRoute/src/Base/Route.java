package Base;

public class Route{
    String name = "";
    int[] routeAsOrders;//Gezilecek hedeflerin hedef numaraları gezilme sırasına göre bu değişkende saklanacak bi iznillâh
    float[] costs;//Ziyaret sıralamasıyla aynı sıralamadaki mâliyyet dizisi. İlk değer = mâliyyet(1. hedef - 2. hedef)
    float totalCost;//Toplam mâliyyet
    Target[] route;//Ziyâret sıralaması

    public Route(){
        
    }

//İŞLEM YÖNTEMLERİ:
    

//ERİŞİM YÖNTEMLERİ:
    public String getName(){
        return name;
    }
    public int[] getRouteAsOrders(){
        return routeAsOrders;
    }
    public Target getTarget(int routeOrderNumber){
        if(routeOrderNumber <= 0)
            return null;
        if(routeOrderNumber > routeAsOrders.length)
            return null;
        return route[routeOrderNumber - 1];
    }
    public float[] getCosts(){
        return costs;
    }
    public float getTotalCost(){
        return totalCost;
    }
    //GİZLİ ERİŞİM YÖNTEMLERİ:
    private String getRouteText(int routeOrderNumber){
        if(routeOrderNumber > route.length)
            return "";
        return route[routeOrderNumber - 1].getName();
    }
}