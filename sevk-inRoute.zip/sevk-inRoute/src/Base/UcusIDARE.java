package Base;

import Services.CryptServ;
import java.util.ArrayList;
import java.util.HashMap;

public class UcusIDARE{
    private static UcusIDARE idare;//Sistemin ta kendisi
    private static String code;//Sistemdeki işlemlerin güvenliğini sağlamak için sistem kodu
    private int counterForTargetID = 1;//Sırasıyla hedef numarası atamak için gereken hedef sayacı
    private int counterForMissionID = 1;//Sırasıyla görev numarası atamak için gereken görev sayacı
    private ArrayList<Integer> usefulTargetIDs;//Sistemde daha önce kullanılan, sonra boşa çıkan kullanılabilir (başka hedefe atanmamış) hedef numaraları
    private ArrayList<Integer> usefulMissionIDs;//Sistemde daha önce kullanılan, sonra boşa çıkan kullanılabilir (başka göreve atanmamış) görev numaraları
    private int counterForVehicleID = 1;//Sırasıyla araç numarası atamak için gereken araç sayacı
    private ArrayList<Integer> usefulVehicleIDs;//Sistemde daha önce kullanılan, sonra boşa çıkan kullanılabilir (başka araca atanmamış) araç numaraları
    
    private Map map;//Sistemdeki mevcut harita
    private Vehicle currentVehicle;//Sistemde şu an kullanılan araç
    private ArrayList<Target> targets;//Sistemdeki hedefler
    private ArrayList<Mission> missions;//Sistemdeki görevler
    private ArrayList<Vehicle> vehicles;//Sistemdeki araçlar
    private boolean removeTargetWhenAMissionUsedThat = false;//"Sistemde hedefi kullanan bir görev olsa bile hedefi kaldırabilirsin" biti
    private HashMap<Integer, Boolean> targetIsUsedInAnyMission;//<Hedef numarası, bu hedefin herhangi bir sistemde kullanılıp, kullanılmadığı>
    private HashMap<Integer, ArrayList<Integer>> targetUsageMap;//<Hedef numarası, bu hedefi kullanan görevlerin görev numaralarının listesi>
    
    private boolean flagSaveLog = true;//Yapılan işlemleri kayıt altına al - alma, bilgisini tutan değişken
    private ArrayList<String> producedVerificationCodes;//Sistem tarafından üretilmiş ve henüz kullanılmamış doğrulama kodlarını barındırır.

    public UcusIDARE(){
        
    }

//İŞLEM YÖNTEMLERİ:
    //ÇALIŞTIRMA YÖNTEMİ:
    public static boolean runIDARE(String code, Map map){
        if(!CryptServ.getService().hashMd5(code).equals(UcusIDARE.code))
            return false;
        if(map == null)
            return false;
        if(map.getWidth() <= 10 || map.getHeight() <= 10)//Bu, doğru bir şart mı, düşün
            return false;
        idare = new UcusIDARE();
        idare.map = map;
        return true;
    }
    public Route convertRouteForFlyable(Route route){
        //.;.
        return null;
    }
    public boolean addTargetToSystem(Target target){
        if(target == null){
            //Exc0 : Gelen veri null
            return false;
        }
        if(!checkIsCanAddOnTheMap(target.getxCoordinate(), target.getYCoordinate())){
            //Exc? : İlgili yerde zâten bir hedef var
            return false;
        }
        if(!checkIsCanUsableNameForTarget(target.getName())){
            //Exc? : Aynı isimde bir hedef var
            return false;
        }
        if(target.getArea() <= 0.0){
            //Exc? : Anlamsız hedef büyüklüğü
            return false;
        }
        if(!this.map.addTargetToMap(target)){
            //Exc? : Beklenmeyen hatâ! : Hedef haritaya eklenemiyor
            return false;
        }
        target.setVerificationCode(produceVerificationCode());
        target.wantID();
        if(target.getID() == -1 || target.getID() == 0){
            //Exc? : Beklenmeyen hatâ : Sistem kesintisinde hedef değişkenine saldırı yapılmış olabilir.
            return false;
        }
        getTargets().add(target);
        return true;
    }
    public int takeIDForTarget(Target target){
        if(target.getVerificationCode() == null){
            //Exc? : Doğrulanmamış bir hedef sistemden hedef numarası istedi
            return -1;
        }
        for(String c : getVerificationCodes()){
            if(c.equals(target.getVerificationCode())){
                //Hedefe hedef numarası veriliyor
                getVerificationCodes().remove(c);
                return takeIDForTarget();
            }
        }
        return -1;
    }
    public int takeIDForMission(Mission mission){
        if(mission.getVerificationCode() == null){
            //Exc? : Doğrulanmamış bir görev değişkeni sistemden hedef numarası istedi
            return -1;
        }
        for(String c : getVerificationCodes()){
            if(c.equals(mission.getVerificationCode())){
                //Göreve görev numarası veriliyor
                getVerificationCodes().remove(c);
                return takeIDForMission();
            }
        }
        return -1;
    }
    public int takeIDForVehicle(Vehicle vehicle){
        if(vehicle.getVerificationCode() == null){
            //Exc? : Doğrulanmamış bir görev değişkeni sistemden hedef numarası istedi
            return -1;
        }
        for(String c : getVerificationCodes()){
            if(c.equals(vehicle.getVerificationCode())){
                //Göreve görev numarası veriliyor
                getVerificationCodes().remove(c);
                return takeIDForVehicle();
            }
        }
        return -1;
    }
    public boolean removeTargetFromSystem(Target target){
        if(target == null)
            return false;
        boolean removeTargetFromMissions = false;
        for(Target t : getTargets()){
            if(t == target){//Hedef sistemde varsa
                if(getTargetIsUsedInAnyMission().get(target.getID())){//Sistemde hedefi kullanan bir görev varsa
                    if(!removeTargetWhenAMissionUsedThat){//"Sistemde hedefi kullanan bir görev olsa bile hedefi kaldırabilirsin" biti "false" ise
                        //Exc? : Sistemde hedefi kullanan bir görev var ve sistem ayarlarında bir görevde kullanılan hedefin kaldırılamaması işâretlenmiş
                        return false;
                    }
                    removeTargetFromMissions = true;
                }
                getTargets().remove(t);
                map.removeTargetFromMap(target);
                getUsefulTargetIDs().add(t.getID());
                getTargetIsUsedInAnyMission().remove(t.getID());
                if(removeTargetFromMissions){
                    ArrayList<Integer> usageMap = new ArrayList<Integer>();
                    usageMap = getTargetUsageMap().get(t.getID());
                    for(int s : usageMap){//Hedef kullanım haritasında ilgili hedef için olan görev listesinden ilgili görevleri bul;
                        findMissionByID(s).removeTarget(t);//o görevlerden bu bu hedefi kaldır
                        getTargetUsageMap().remove(s);//Hedef kullanım haritasındaki ilgili hedef için olan listeden ilgili görevi kaldır
                    }
                    getTargetIsUsedInAnyMission().remove(t.getID());
                }
                //İşlem başarılı
                return true;
            }
        }
        //Exc? : Hedef sistemde mevcut değil
        return false;
    }
    public boolean addMissionToSystem(Mission mission){
        if(mission == null){
            //Exc0 : Gelen veri null
            return false;
        }
        if(!checkIsCanUsableNameForMission(mission.getName())){
            //Exc? : Aynı isimde bir hedef var
            return false;
        }
        mission.setVerificationCode(produceVerificationCode());
        mission.wantID();
        if(mission.getID() == -1 || mission.getID() == 0){
            //Exc? : Beklenmeyen hatâ : Sistem kesintisinde görev değişkenine saldırı yapılmış olabilir.
            return false;
        }
        getMissions().add(mission);
        for(Target t : mission.getTargets()){//Hedef kullanım haritasına hedefleri kullanan görevler listesine görev numarasını ekle
            if(getTargetUsageMap().get(t.getID()) == null){
                getTargetUsageMap().put(t.getID(), new ArrayList<Integer>());
            }
            getTargetUsageMap().get(t.getID()).add(mission.getID());
        }
        return true;
    }
    public boolean removeMissionFromSystem(Mission mission){
        if(mission == null){
            //Exc0 : Gelen veri null
            return false;
        }
        for(Mission m : getMissions()){
            if(m == mission){//Görev sistemde varmış
                getMissions().remove(m);
                getUsefulMissionIDs().add(m.getID());
                for(Target t : m.getTargets()){//Hedef kullanım haritasında ilgili hedefi kullananların listesinden kaldırılacak olan görevi numarasını kaldır
                    getTargetUsageMap().get(t.getID()).remove(m.getID());
                }
                //İşlem başarılı
                return true;
            }
        }
        //Exc? : Görev sistemde mevcut değil
        return false;
    }
    public boolean addVehicleToSystem(Vehicle vehicle){
        if(vehicle == null){
            //Exc0 : Gelen veri null
            return false;
        }
        if(!checkIsCanUsableNameForVehicle(vehicle.getName())){
            //Exc? : Aynı isimde bir araç var
            return false;
        }
        vehicle.setVerificationCode(produceVerificationCode());
        vehicle.wantID();
        if(vehicle.getID() == -1 || vehicle.getID() == 0){
            //Exc? : Beklenmeyen hatâ : Sistem kesintisinde araç değişkenine saldırı yapılmış olabilir.
            return false;
        }
        getVehicles().add(vehicle);
        return true;
    }
    public boolean removeVehicleFromSystem(Vehicle vehicle){
        if(vehicle == null){
            //Exc? : Gelen veri null
            return false;
        }
        for(Vehicle v : getVehicles()){
            if(v == vehicle){//Araç sistemde varmış
                getVehicles().remove(v);
                getUsefulVehicleIDs().add(v.getID());
                //İşlem başarılı
                return true;
            }
        }
        //Exc? : Araç sistemde mevcut değil
        return false;
    }
    public Target findTargetByID(int targetID){
        for(Target t : getTargets()){
            if(t.getID() == targetID)
                return t;
        }
        return null;
    }
    public Vehicle findVehicleByID(int vehicleID){
        for(Vehicle v : getVehicles()){
            if(v.getID() == vehicleID)
                return v;
        }
        return null;
    }
    public Mission findMissionByID(int missionID){
        for(Mission m : getMissions()){
            if(m.getID() == missionID)
                return m;
        }
        return null;
    }
    //ARKAPLAN İŞLEM YÖNTEMLERİ:
    private boolean checkIsCanAddOnTheMap(double x, double y){
        if(x >= map.getWidth() || y >= map.getHeight())
            return false;
        return map.getArea()[(int)y][(int)x];
    }
    private boolean checkIsCanUsableNameForTarget(String targetName){
        for(Target n : getTargets()){
            if(n.getName().equals(targetName))
                return false;
        }
        return true;
    }
    private boolean checkIsCanUsableNameForVehicle(String vehicleName){
        for(Vehicle n : getVehicles()){
            if(n.getName().equals(vehicleName))
                return false;
        }
        return true;
    }
    private boolean checkIsCanUsableNameForMission(String missionName){
        for(Mission n : getMissions()){
            if(n.getName().equals(missionName))
                return false;
        }
        return true;
    }
    private String produceVerificationCode(){
        StringBuilder c = new StringBuilder();
        //.;. : Münhasır kod üret
        getVerificationCodes().add(c.toString());
        return "";
    }
    private int takeIDForTarget(){
        if(!getUsefulTargetIDs().isEmpty()){
            int no = getUsefulTargetIDs().get(0);
            getUsefulTargetIDs().remove(no);
            return no;
        }
        this.counterForTargetID++;
        return counterForTargetID - 1;
    }
    private int takeIDForMission(){
        if(!getUsefulMissionIDs().isEmpty()){
            int no = getUsefulMissionIDs().get(0);
            getUsefulMissionIDs().remove(no);
            return no;
        }
        this.counterForMissionID++;
        return counterForMissionID - 1;
    }
    private int takeIDForVehicle(){
        if(!getUsefulVehicleIDs().isEmpty()){
            int no = getUsefulVehicleIDs().get(0);
            getUsefulVehicleIDs().remove(no);
            return no;
        }
        this.counterForVehicleID++;
        return counterForVehicleID - 1;
    }

//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static UcusIDARE getIDARE(){
        return idare;
    }
    public ArrayList<Target> getTargets(){
        if(targets == null)
            targets = new ArrayList<Target>();
        return targets;
    }
    public ArrayList<Mission> getMissions(){
        if(missions == null)
            missions = new ArrayList<Mission>();
        return missions;
        
    }
    public ArrayList<Vehicle> getVehicles(){
        if(vehicles == null)
            vehicles = new ArrayList<Vehicle>();
        return vehicles;
        
    }
    //GİZLİ ERİŞİM YÖNTEMLERi:
    private ArrayList<Integer> getUsefulTargetIDs(){
        if(usefulTargetIDs == null)
            usefulTargetIDs = new ArrayList<Integer>();
        return usefulTargetIDs;
    }
    private ArrayList<Integer> getUsefulMissionIDs(){
        if(usefulMissionIDs == null)
            usefulMissionIDs = new ArrayList<Integer>();
        return usefulMissionIDs;
    }
    private ArrayList<Integer> getUsefulVehicleIDs(){
        if(usefulVehicleIDs == null)
            usefulVehicleIDs = new ArrayList<Integer>();
        return usefulVehicleIDs;
    }
    private ArrayList<String> getVerificationCodes(){
        if(producedVerificationCodes == null)
            producedVerificationCodes = new ArrayList<String>();
        return producedVerificationCodes;
    }
    private HashMap<Integer, Boolean> getTargetIsUsedInAnyMission(){
        if(targetIsUsedInAnyMission == null)
            targetIsUsedInAnyMission = new HashMap<Integer, Boolean>();
        return targetIsUsedInAnyMission;
    }
    private HashMap<Integer, ArrayList<Integer>> getTargetUsageMap(){
        if(targetUsageMap == null)
            targetUsageMap = new HashMap<Integer, ArrayList<Integer>>();
        return targetUsageMap;
    }
}