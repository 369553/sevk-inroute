package Control;

import Views.EntryPage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActEntryPage implements ActionListener{
    EntryPage page;
    String code;

    public ActEntryPage(EntryPage page, String code){
        this.page = page;
        this.code = code;
        
        page.getBtnBackTo().addActionListener(this);
        /*
        page.getBtnNoAnswer().addActionListener(this);
        page.getBtnMySql().addActionListener(this);
        page.getBtnHatirDB().addActionListener(this);
        page.getBtnChooseFile().addActionListener(this);
        page.getBtnComplete().addActionListener(this);
        page.getBtnBackTo().addActionListener(this);
        page.getBtnRunWithoutDB().addActionListener(this);
*/
    }

//İŞLEM YÖNTEMLERİ:
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == page.getBtnBackTo()){
            if(page.getStepNo() == 1)
                return;
        }
    }

//ERİŞİM YÖNTEMLERİ:
    
    
}
