package Algorithms;

public class IAlgorithm {

    public IAlgorithm(){
        
    }

//İŞLEM YÖNTEMLERİ:
    

//ERİŞİM YÖNTEMLERİ:
    
}