package Views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;

public class MainFrame extends JFrame{
    public static MainFrame FrameMain;
    public static BorderLayout compOrder;

    private MainFrame(){}

    public static MainFrame getFrameMain(){
        if(FrameMain == null){
            FrameMain = new MainFrame();
            compOrder = new BorderLayout();
            FrameMain.setLayout(compOrder);
            FrameMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            Frame_Main.setBounds( 140, 15, 1080, 720 );//ESKİ AYAR
            FrameMain.setBounds(260, 100, 810, 540);
            FrameMain.setMinimumSize( new Dimension (600, 400));
            //Gerek yok, çünkü frame de boşlu yok Frame_Main.setBackground( Color.decode (SystemSettings.getSettings().getCurrentTheme().getBackgroundColor() ) );
            //Frame_Main.setMinimumSize( new Dimension (600, 400) ) ;
        }
        return FrameMain ;
    }
    public void meaningFrame(Dimension screenDimension){
        int startX = ((screenDimension.width - this.getMinimumSize().width) / 2) - 10;
//        System.out.println("screenDimension.width ("  + screenDimension.width + ") - minimumSize.width(" + Frame_Main.getMinimumSize().width + ") / 2 = " + startX);
        int startY = ((screenDimension.height - this.getMinimumSize().height) / 2) - 7;
        this.setBounds(startX, startY, this.getMinimumSize().width, this.getMinimumSize().height);
    }
}