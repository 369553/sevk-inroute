package Views;

import Control.GUISeeming;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class ContactPanel extends JPanel{
    private static ContactPanel contactPanel; 
    private HashMap<String, String> messageTypesAndColor;
    private Font messageFont;
    private String textColor = "#44d794";
    String messageType;
    private JScrollPane scrpanePanel;
    private JList<JLabel> liMessages;
    private DefaultListModel<JLabel> mdlMessagesList;
    private BorderLayout compOrder;
    private RenderForList renderMessagesList;
    private MessageDisposing thDispose;
    private JLabel lblFrontSide;

    public ContactPanel(){
        this.setBackground(Color.decode("#F5F5DC"));
        this.setForeground(Color.decode("#7B3F00"));
        this.setLayout(getCompOrder());
        this.setPreferredSize(new Dimension(MainFrame.getFrameMain().getWidth() - 10, MainFrame.getFrameMain().getHeight() / 7));
        this.add(getScrpanePanel(), BorderLayout.CENTER);
        this.add(getLblFrontSide(), BorderLayout.LINE_START);
        GUISeeming.appGUI(this);
    }

//İŞLEM YÖNTEMLERİ:
    public void showMessage(String messageText, String messageType){
        boolean isMessageTypeTrue = false;
        String strMessageColor = getMessageTypesAndColor().get(messageType);
        if(strMessageColor != null){
            this.textColor = strMessageColor;
            isMessageTypeTrue = true;
        }
        else
            strMessageColor = getMessageTypesAndColor().get("Standard");
        if(isMessageTypeTrue)
            setMessageType(messageType);
        else
            setMessageType("Standard");
        showMessage(messageText);
    }
    public void showMessage(String messageText){
        appGUI();
        getMdlMessagesList().addElement(getNewGUITextForMessage(messageText));
        getLblFrontSide().setText(messageText);
        getLblFrontSide().setVisible(true);//Bunun yerine lblFrontSide'ı panele ekle - çıkar yapman gerekebilir
        //zîrâ BorderLayout üst üste eklemeyi desteklemiyor olabilir.
        thDispose = new MessageDisposing();
        setVisible(true);
    }
    public void changeSize(int width, int height){
        this.setPreferredSize(new Dimension(width, height));
    }
    public void updateSeeming(){
        String[] strColors = GUISeeming.getColorsForContactPanel();
            getMessageTypesAndColor().put("Standard", strColors[0]);
            getMessageTypesAndColor().put("Warning", strColors[1]);
            getMessageTypesAndColor().put("Successful", strColors[2]);
            getMessageTypesAndColor().put("LittlePoint", strColors[3]);
            getMessageTypesAndColor().put("Info", strColors[4]);
            getMessageTypesAndColor().put("Advice", strColors[5]);
        if(GUISeeming.getSeeming().equals("Dark"))
            textColor = "#727080";
        else
            textColor = "#0e2613";
        updateListModel();
     }
    public void setMessageType(String messageType){
        this.messageType = messageType;
    }
    //ARKAPLAN İŞLEM YÖNTEMLERİ:
    private void removeMessages(){
        this.getMdlMessagesList().removeAllElements();
        this.setVisible(true);
    }
    private void updateListModel(){
        getLiMessages().setBackground(Color.decode(GUISeeming.getSeeming().getHexBackgroundColor()));
        getLiMessages().setForeground(Color.decode(GUISeeming.getSeeming().getHexTextColor()));
        getLiMessages().setSelectionBackground(Color.decode(GUISeeming.getSeeming().getHexButtonColor()));
        getLiMessages().setSelectionForeground(Color.decode(GUISeeming.getSeeming().getHexButtonTextColor()));
    }
    private void removeFrontSide(){
        getLblFrontSide().setVisible(false);
    }
    private void appGUI(){
        getLblFrontSide().setBackground(Color.decode(getMessageColor()));
        getLblFrontSide().setForeground(Color.decode(getTextColor()));
    }

//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static ContactPanel getContactPanel(){
        if(contactPanel == null){
            contactPanel = new ContactPanel();
        }
        return contactPanel;
    }
    public HashMap<String, String> getMessageTypesAndColor() {
        if(messageTypesAndColor == null){
            String[] strColors = GUISeeming.getColorsForContactPanel();
            messageTypesAndColor = new HashMap<String, String>();
            messageTypesAndColor.put("Standard", strColors[0]);//"#e1625e"
            messageTypesAndColor.put("Warning", strColors[1]);//"#e1625e"
            messageTypesAndColor.put("Successful", strColors[2]);//"#44d794"
            messageTypesAndColor.put("LittlePoint", strColors[3]);//"#e1c5bd"
            messageTypesAndColor.put("Info", strColors[4]);//"#778edd"
            messageTypesAndColor.put("Advice", strColors[5]);//"#fac35b"
        }
        return messageTypesAndColor;
    }
    public JLabel getNewGUITextForMessage(String messageText) {
        JLabel lblMessage = new JLabel(messageText);
        lblMessage.setFont(getMessageFont());
        lblMessage.setOpaque(true);
        lblMessage.setHorizontalAlignment(JLabel.HORIZONTAL);
        lblMessage.setBackground(Color.decode(textColor));
        return lblMessage;
    }
    public Font getMessageFont() {
        if(messageFont == null){
            messageFont = new Font("Dialog", Font.BOLD | Font.ITALIC, 14);
        }
        return messageFont;
    }

    public JScrollPane getScrpanePanel() {
        if(scrpanePanel == null){
            scrpanePanel = new JScrollPane(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scrpanePanel.setViewportView(getLiMessages());
        }
        return scrpanePanel;
    }
    public JList<JLabel> getLiMessages() {
        if(liMessages == null){
            liMessages = new JList<JLabel>();
            liMessages.setModel(getMdlMessagesList());
            liMessages.setBackground(Color.decode(GUISeeming.getSeeming().getHexBackgroundColor()));
            liMessages.setForeground(Color.decode(GUISeeming.getSeeming().getHexTextColor()));
            liMessages.setSelectionBackground(Color.decode(GUISeeming.getSeeming().getHexButtonColor()));
            liMessages.setSelectionForeground(Color.decode(GUISeeming.getSeeming().getHexButtonTextColor()));
            liMessages.setFont(getMessageFont());
            liMessages.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.decode("#aca090")));
            liMessages.setCellRenderer(getRenderMessagesList());
        }
        return liMessages;
    }
    private DefaultListModel<JLabel> getMdlMessagesList(){
        if(mdlMessagesList == null){
            mdlMessagesList = new DefaultListModel<JLabel>();
        }
        return mdlMessagesList;
    }
    public BorderLayout getCompOrder(){
        if(compOrder == null){
            compOrder = new BorderLayout(0, 0);
        }
        return compOrder;
    }
    public RenderForList getRenderMessagesList(){
        if(renderMessagesList == null){
            renderMessagesList = RenderForList.produceConfiguredRenderer(this, "getRenderColor", getMessageFont());
        }
        return renderMessagesList;
    }
    public String getRenderColor(){
        return textColor;
    }
    public String getTextColor(){
        if(textColor == null){
            if(GUISeeming.getSeeming().getSeemingName().equals("Dark"))
                textColor = "#727080";
            else
                textColor = "#0e2613";
        }
        return textColor;
    }
    public JLabel getLblFrontSide(){
        if(lblFrontSide == null){
            lblFrontSide = new JLabel("");
            lblFrontSide.setBackground(this.getLiMessages().getBackground());
            lblFrontSide.setForeground(this.getLiMessages().getForeground());
            lblFrontSide.setPreferredSize(this.getPreferredSize());
            lblFrontSide.setVisible(false);
        }
        return lblFrontSide;
    }
    public String getMessageColor(){
        if(getMessageTypesAndColor().get(getMessageType()) != null)
           return getMessageTypesAndColor().get(getMessageType());
        return GUISeeming.getSeeming().getHexBackgroundColor();
    }
    public String getMessageType(){
        if(messageType == null){
            messageType = "Info";
        }
        return messageType;
    }

//İÇ SINIF:
    private class MessageDisposing extends Thread{
        public MessageDisposing(){
            start();
        }

    //İÇ SINIF İŞLEM YÖNTEMLERİ:
        @Override
        public void run(){
            try{
                Thread.sleep(4444);
                
            }
            catch(InterruptedException e){
                System.out.println("İletişim paneliyle ilgili işlem kesintisi oldu");
            }
            ContactPanel.getContactPanel().removeFrontSide();
        }
    }
}