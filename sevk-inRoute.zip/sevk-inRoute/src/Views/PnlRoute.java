package Views;

import Base.Route;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;

public class PnlRoute extends JPanel{
    private Route route;
    JLabel lblRouteNameText, lblRouteNameInfo, lblTotalCostText, lblTotalCostInfo, lblRouteOrderText, lblSelectedRouteCostText, lblSelectedRouteCostInfo;
    JList<String> liRouteOrder;
    DefaultListModel<String> mdlLiRouteOrder;
    

    public PnlRoute(Route route){
        this.route = route;
    }

//İŞLEM YÖNTEMLERİ:
    //GİZLİ İŞLEM YÖNTEMLERİ:
    private void fillList(){
        if(mdlLiRouteOrder == null)
            return;
        for(int sayac = 0; sayac < route.getRouteAsOrders().length; sayac++){
            mdlLiRouteOrder.addElement(route.getTarget(sayac).getName());
        }
    }

//ERİŞİM YÖNTEMLERİ:
    public JLabel getLblSelectedRouteCostText(){
        if(lblSelectedRouteCostText == null){
            lblSelectedRouteCostText = new JLabel("Seçili güzergâh mâliyyeti :");
        }
        return lblSelectedRouteCostText;
    }
    public JLabel getLblSelectedRouteCostInfo(){
        if(lblSelectedRouteCostInfo == null){
            lblSelectedRouteCostInfo = new JLabel("");
        }
        return lblSelectedRouteCostInfo;
    }
    public JLabel getLblRouteNameText(){
        if(lblRouteNameText == null){
            lblRouteNameInfo = new JLabel("Güzergâh ismi :");
        }
        return lblRouteNameText;
    }
    public JLabel getLblRouteNameInfo(){
        if(lblRouteNameInfo == null){
            lblRouteNameText = new JLabel("");
            if(this.route != null)
                lblRouteNameText.setText(this.route.getName());
        }
        return lblRouteNameInfo;
    }
    public JLabel getLblTotalCostText(){
        if(lblTotalCostText == null){
            lblTotalCostText = new JLabel("Toplam mâliyyet :");
        }
        return lblTotalCostText;
    }
    public JLabel getLblTotalCostInfo(){
        if(lblTotalCostInfo == null){
            lblTotalCostInfo = new JLabel("0");
            if(route != null)
                lblTotalCostInfo.setText(String.valueOf(route.getTotalCost()));
        }
        return lblTotalCostInfo;
    }
    public JLabel getLblRouteOrderText(){
        if(lblRouteOrderText == null){
            lblRouteOrderText = new JLabel("Güzergâh sırası:");
        }
        return lblRouteOrderText;
    }
    public JList<String> getLiRouteOrder(){
        if(liRouteOrder == null){
            liRouteOrder = new JList<String>();
            liRouteOrder.setModel(getMdlLiRouteOrder());
        }
        return liRouteOrder;
    }
    public DefaultListModel<String> getMdlLiRouteOrder(){
        if(mdlLiRouteOrder == null){
            mdlLiRouteOrder = new DefaultListModel<String>();
            fillList();
        }
        return mdlLiRouteOrder;
    }
}