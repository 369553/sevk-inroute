package Views;

import Control.Add;
import Control.GUISeeming;
import Control.Movements;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JButton;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;

public class EntryPage extends JFrame{
    private static EntryPage entryPage;
    int stepNo;
    JPanel pnlContent;
    BorderLayout order;
    JButton btnBackTo;
    JLabel lblMessageText;

    private EntryPage(){
        super("sevk-in Route");
        this.setLayout(getOrder());
        Dimension systemSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setBounds(systemSize.width / 7, systemSize.height / 7, 2 * (systemSize.width / 3), 2 * (systemSize.height / 3));
        this.setPreferredSize(new Dimension(systemSize.width / 2, systemSize.height / 2));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.add(getPnlContent(), BorderLayout.CENTER);
        runStep1();
        GUISeeming.appGUI(this.getContentPane());
    }

//İŞLEM YÖNTEMLERİ:
    public void updateSeeming(){
        GUISeeming.appGUI(this.getPnlContent());
        this.getLblMessageText().setFont(this.getLblMessageText().getFont().deriveFont(Font.BOLD | Font.ITALIC, 17));
        this.setVisible(true);
    }
    public void addContactPanel(){
        this.add(ContactPanel.getContactPanel(), BorderLayout.SOUTH);
    }
    public void addBtnBackTo(){
        this.add(getBtnBackTo(), BorderLayout.NORTH);
    }
    public void runStep1(){
        stepNo = 1;
        Add.addComp(this, getLblMessageText(), 0, 0, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.CENTER, 1.0, 1.0);
        addBtnBackTo();
        //Buraya ekle
        //Buraya eklenenlere 'ActionListener' ekle (EntryPageActs'de)
    }

//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static EntryPage getEntryPage(){
        if(entryPage == null){
             entryPage = new EntryPage();
        }
        return entryPage;
    }
    public BorderLayout getOrder(){
        if(order == null){
            order = new BorderLayout(5, 5);
        }
        return order;
    }
    public JPanel getPnlContent(){
        if(pnlContent == null){
            pnlContent = new JPanel();
            pnlContent.setLayout(new GridBagLayout());
            pnlContent.setPreferredSize(new Dimension(500, 200));
        }
        return pnlContent;
    }
    public JLabel getLblMessageText(){
        if(lblMessageText == null)
            lblMessageText = new JLabel();
        return lblMessageText;
    }
    public JButton getBtnBackTo(){
        if(btnBackTo == null)
            btnBackTo = new JButton("ÖNCEKİ ADIMA GERİ DÖN");
        return btnBackTo;
    }
    public int getStepNo(){
        return stepNo;
    }
}