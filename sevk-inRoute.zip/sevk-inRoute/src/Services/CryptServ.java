package Services;

public class CryptServ{
    private static CryptServ service;

    private CryptServ(){
        
    }

//İŞLEM YÖNTEMLERİ:
    public String hashMd5(String openText){
        StringBuilder md5T = new StringBuilder();
        //...
        return md5T.toString();
    }

//ERİŞİM YÖNTEMLERi:
    //ANA ERİŞİM YÖNTEMİ:
    public static CryptServ getService(){
        if(service == null){
            service = new CryptServ();
        }
        return service;
    }
}